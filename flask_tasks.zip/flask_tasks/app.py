from flask import Flask, request, render_template
res = Flask(__name__)
@res.route("/")
def sum():
    var_1 = int(request.args.get("a"))
    var_2 = int(request.args.get("b"))
    return str(var_1+var_2)
@res.route("/about")
def res1():
    return render_template("text_2.html")

if __name__ == "__main__":
    res.run(debug = True)